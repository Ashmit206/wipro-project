import java.util.*;
class Month {
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<>();
		list.add("Jan");
		list.add("Feb");
		list.add("Mar");
		list.add("Apr");
		list.add("May");
		list.add("Jun");
		list.add("Jul");
		list.add("Aug");
		list.add("Sep");
		list.add("Oct");
		list.add("Nov");
		list.add("Dec");
		for(String a : list){
			System.out.println(a);
		}

	}
}


