/*Write a program to print even numbers between 23 and 57. Each number should be printed in a separate row.
Solution:
*/
class Main {
	public static void main(String[] args) {
		for (int i=24;i<58 ;i=i+2 )
 {
			System.out.println(i);
		}
	}
}
