/* Write a program to check if a given integer number is Positive, Negative, or Zero. 
Solution:
*/
class Main{
	public static void main(String[] args) {
		int a =324;
		if(a>0)
			System.out.println(a+" is Positive integer");
		else if(a<0)
			System.out.println(a+" is Negative integer");
		else
			System.out.println(a+" is Zero");

		}
}
