/*Initialize two character variables in a program and display the characters in alphabetical order.
Solution:
*/
class Main {
	public static void main(String[] args) {
		char a = 'a';
		char s = 'e';
		if(a<s)
			System.out.print(a+","+s);
		else 
			System.out.print(s+","+a);
		
	}
}

