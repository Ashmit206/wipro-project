/* Write a Program that accepts two Strings as command line arguments and generate the output in the required format. 

Example)
If the two command line arguments are Wipro and Bangalore then the output generated should be Wipro Technologies Bangalore.
Solution: 
*/
class Main {
	public static void main( String[] args) {
		System.out.print(args[0]+" Technologies "+args[1]);
	}
}
