DESC departments;
SELECT * FROM departments;
