SELECT last_name
FROM employees
WHERE last_name like ‘__a%’;
