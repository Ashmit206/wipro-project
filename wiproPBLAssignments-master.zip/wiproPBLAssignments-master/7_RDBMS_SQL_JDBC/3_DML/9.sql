DELETE 
FROM MY_EMPLOYEE 
WHERE first_name LIKE '%man%' OR last_name LIKE '%man%';	

